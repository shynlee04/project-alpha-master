2025-12-21T07:51:13.806Z	Initializing build environment...
2025-12-21T07:52:22.783Z	Success: Finished initializing build environment
2025-12-21T07:52:23.137Z	Cloning repository...
2025-12-21T07:52:24.310Z	Detected the following tools from environment: pnpm@10.11.1, nodejs@22.16.0
2025-12-21T07:52:24.311Z	Restoring from dependencies cache
2025-12-21T07:52:24.313Z	Restoring from build output cache
2025-12-21T07:52:24.569Z	Installing project dependencies: pnpm install --frozen-lockfile
2025-12-21T07:52:25.330Z	Lockfile is up to date, resolution step is skipped
2025-12-21T07:52:25.412Z	Progress: resolved 1, reused 0, downloaded 0, added 0
2025-12-21T07:52:25.549Z	Packages: +1018
2025-12-21T07:52:25.550Z	++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
2025-12-21T07:52:26.412Z	Progress: resolved 1018, reused 0, downloaded 15, added 0
2025-12-21T07:52:27.412Z	Progress: resolved 1018, reused 0, downloaded 66, added 61
2025-12-21T07:52:28.412Z	Progress: resolved 1018, reused 0, downloaded 174, added 172
2025-12-21T07:52:29.413Z	Progress: resolved 1018, reused 0, downloaded 309, added 300
2025-12-21T07:52:30.417Z	Progress: resolved 1018, reused 0, downloaded 388, added 374
2025-12-21T07:52:31.417Z	Progress: resolved 1018, reused 0, downloaded 397, added 382
2025-12-21T07:52:32.417Z	Progress: resolved 1018, reused 0, downloaded 435, added 421
2025-12-21T07:52:33.418Z	Progress: resolved 1018, reused 0, downloaded 605, added 598
2025-12-21T07:52:34.421Z	Progress: resolved 1018, reused 0, downloaded 812, added 808
2025-12-21T07:52:35.422Z	Progress: resolved 1018, reused 0, downloaded 996, added 987
2025-12-21T07:52:35.624Z	Progress: resolved 1018, reused 0, downloaded 1018, added 1018, done
2025-12-21T07:52:35.901Z	.../esbuild@0.27.2/node_modules/esbuild postinstall$ node install.js
2025-12-21T07:52:35.901Z	.../node_modules/@parcel/watcher install$ node scripts/build-from-source.js
2025-12-21T07:52:35.906Z	.../sharp@0.33.5/node_modules/sharp install$ node install/check
2025-12-21T07:52:35.907Z	.../esbuild@0.27.0/node_modules/esbuild postinstall$ node install.js
2025-12-21T07:52:35.907Z	.../node_modules/workerd postinstall$ node install.js
2025-12-21T07:52:35.973Z	.../node_modules/@parcel/watcher install: Done
2025-12-21T07:52:36.041Z	.../esbuild@0.27.2/node_modules/esbuild postinstall: Done
2025-12-21T07:52:36.041Z	.../sharp@0.34.5/node_modules/sharp install$ node install/check.js || npm run build
2025-12-21T07:52:36.159Z	.../node_modules/workerd postinstall: Done
2025-12-21T07:52:36.166Z	.../esbuild@0.27.0/node_modules/esbuild postinstall: Done
2025-12-21T07:52:36.186Z	.../sharp@0.34.5/node_modules/sharp install: Done
2025-12-21T07:52:36.191Z	.../sharp@0.33.5/node_modules/sharp install: Done
2025-12-21T07:52:36.687Z	
2025-12-21T07:52:36.687Z	dependencies:
2025-12-21T07:52:36.687Z	+ @monaco-editor/react 4.7.0
2025-12-21T07:52:36.689Z	+ @radix-ui/react-dialog 1.1.15
2025-12-21T07:52:36.689Z	+ @radix-ui/react-dropdown-menu 2.1.16
2025-12-21T07:52:36.689Z	+ @radix-ui/react-label 2.1.8
2025-12-21T07:52:36.689Z	+ @radix-ui/react-select 2.2.6
2025-12-21T07:52:36.689Z	+ @radix-ui/react-separator 1.1.8
2025-12-21T07:52:36.689Z	+ @radix-ui/react-slot 1.2.4
2025-12-21T07:52:36.689Z	+ @radix-ui/react-switch 1.2.6
2025-12-21T07:52:36.689Z	+ @radix-ui/react-tabs 1.1.13
2025-12-21T07:52:36.690Z	+ @sentry/react 10.32.1
2025-12-21T07:52:36.690Z	+ @tailwindcss/vite 4.1.18
2025-12-21T07:52:36.690Z	+ @tanstack/ai 0.1.0
2025-12-21T07:52:36.690Z	+ @tanstack/ai-gemini 0.1.0
2025-12-21T07:52:36.690Z	+ @tanstack/ai-react 0.1.0
2025-12-21T07:52:36.690Z	+ @tanstack/react-devtools 0.7.11
2025-12-21T07:52:36.690Z	+ @tanstack/react-router 1.141.8
2025-12-21T07:52:36.690Z	+ @tanstack/react-router-devtools 1.141.8
2025-12-21T07:52:36.690Z	+ @tanstack/react-router-ssr-query 1.141.8
2025-12-21T07:52:36.690Z	+ @tanstack/react-start 1.142.0
2025-12-21T07:52:36.690Z	+ @tanstack/react-store 0.8.0
2025-12-21T07:52:36.690Z	+ @tanstack/router-plugin 1.142.0
2025-12-21T07:52:36.690Z	+ @tanstack/store 0.8.0
2025-12-21T07:52:36.690Z	+ @webcontainer/api 1.6.1
2025-12-21T07:52:36.690Z	+ @xterm/addon-fit 0.10.0
2025-12-21T07:52:36.690Z	+ @xterm/xterm 5.5.0
2025-12-21T07:52:36.690Z	+ class-variance-authority 0.7.1
2025-12-21T07:52:36.690Z	+ clsx 2.1.1
2025-12-21T07:52:36.690Z	+ eventemitter3 5.0.1
2025-12-21T07:52:36.690Z	+ i18next 23.16.8
2025-12-21T07:52:36.690Z	+ i18next-browser-languagedetector 8.2.0
2025-12-21T07:52:36.691Z	+ idb 8.0.3
2025-12-21T07:52:36.691Z	+ isomorphic-git 1.36.1
2025-12-21T07:52:36.691Z	+ lucide-react 0.544.0
2025-12-21T07:52:36.691Z	+ monaco-editor 0.55.1
2025-12-21T07:52:36.691Z	+ next-themes 0.4.6
2025-12-21T07:52:36.691Z	+ react 19.2.3
2025-12-21T07:52:36.691Z	+ react-dom 19.2.3
2025-12-21T07:52:36.691Z	+ react-i18next 15.7.4
2025-12-21T07:52:36.691Z	+ react-resizable-panels 3.0.6
2025-12-21T07:52:36.691Z	+ sonner 2.0.7
2025-12-21T07:52:36.691Z	+ tailwind-merge 3.4.0
2025-12-21T07:52:36.691Z	+ tailwindcss 4.1.18
2025-12-21T07:52:36.691Z	+ vite-tsconfig-paths 5.1.4
2025-12-21T07:52:36.691Z	+ zod 4.2.1
2025-12-21T07:52:36.691Z	
2025-12-21T07:52:36.691Z	devDependencies:
2025-12-21T07:52:36.691Z	+ @cloudflare/vite-plugin 1.19.0
2025-12-21T07:52:36.691Z	+ @netlify/vite-plugin-tanstack-start 1.2.5
2025-12-21T07:52:36.691Z	+ @tanstack/devtools-vite 0.3.12
2025-12-21T07:52:36.691Z	+ @testing-library/dom 10.4.1
2025-12-21T07:52:36.692Z	+ @testing-library/jest-dom 6.9.1
2025-12-21T07:52:36.692Z	+ @testing-library/react 16.3.1
2025-12-21T07:52:36.692Z	+ @types/i18next-browser-languagedetector 3.0.0
2025-12-21T07:52:36.692Z	+ @types/jest-axe 3.5.9
2025-12-21T07:52:36.692Z	+ @types/node 22.19.3
2025-12-21T07:52:36.692Z	+ @types/react 19.2.7
2025-12-21T07:52:36.696Z	+ @types/react-dom 19.2.3
2025-12-21T07:52:36.696Z	+ @types/react-i18next 8.1.0
2025-12-21T07:52:36.696Z	+ @vitejs/plugin-react 5.1.2
2025-12-21T07:52:36.696Z	+ axe-core 4.11.0
2025-12-21T07:52:36.696Z	+ fake-indexeddb 6.2.5
2025-12-21T07:52:36.696Z	+ i18next-scanner 4.6.0
2025-12-21T07:52:36.696Z	+ jest-axe 9.0.0
2025-12-21T07:52:36.696Z	+ jsdom 27.3.0
2025-12-21T07:52:36.696Z	+ tw-animate-css 1.4.0
2025-12-21T07:52:36.696Z	+ typescript 5.9.3
2025-12-21T07:52:36.696Z	+ vite 7.3.0
2025-12-21T07:52:36.696Z	+ vitest 3.2.4
2025-12-21T07:52:36.696Z	+ vitest-axe 0.1.0
2025-12-21T07:52:36.697Z	+ web-vitals 5.1.0
2025-12-21T07:52:36.697Z	+ wrangler 4.56.0
2025-12-21T07:52:36.697Z	
2025-12-21T07:52:36.708Z	Done in 11.8s
2025-12-21T07:52:36.831Z	Executing user build command: pnpm run build
2025-12-21T07:52:37.158Z	
2025-12-21T07:52:37.158Z	> project-alpha@ build /opt/buildhome/repo
2025-12-21T07:52:37.158Z	> vite build
2025-12-21T07:52:37.158Z	
2025-12-21T07:52:41.811Z	error during build:
2025-12-21T07:52:41.811Z	Error: The provided Wrangler config main field (/opt/buildhome/repo/.output/server/index.mjs) doesn't point to an existing file
2025-12-21T07:52:41.811Z	    at maybeResolveMain (file:///opt/buildhome/repo/node_modules/.pnpm/@cloudflare+vite-plugin@1.19.0_vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2__phrwqvloyicnqdru5eociwwghi/node_modules/@cloudflare/vite-plugin/dist/index.mjs:8394:44)
2025-12-21T07:52:41.812Z	    at resolveWorkerType (file:///opt/buildhome/repo/node_modules/.pnpm/@cloudflare+vite-plugin@1.19.0_vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2__phrwqvloyicnqdru5eociwwghi/node_modules/@cloudflare/vite-plugin/dist/index.mjs:8364:23)
2025-12-21T07:52:41.814Z	    at resolveWorkerConfig (file:///opt/buildhome/repo/node_modules/.pnpm/@cloudflare+vite-plugin@1.19.0_vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2__phrwqvloyicnqdru5eociwwghi/node_modules/@cloudflare/vite-plugin/dist/index.mjs:8470:9)
2025-12-21T07:52:41.814Z	    at resolvePluginConfig (file:///opt/buildhome/repo/node_modules/.pnpm/@cloudflare+vite-plugin@1.19.0_vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2__phrwqvloyicnqdru5eociwwghi/node_modules/@cloudflare/vite-plugin/dist/index.mjs:8494:36)
2025-12-21T07:52:41.814Z	    at BasicMinimalPluginContext.config (file:///opt/buildhome/repo/node_modules/.pnpm/@cloudflare+vite-plugin@1.19.0_vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2__phrwqvloyicnqdru5eociwwghi/node_modules/@cloudflare/vite-plugin/dist/index.mjs:17747:33)
2025-12-21T07:52:41.814Z	    at runConfigHook (file:///opt/buildhome/repo/node_modules/.pnpm/vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2_tsx@4.21.0_yaml@2.8.2/node_modules/vite/dist/node/chunks/config.js:35934:42)
2025-12-21T07:52:41.814Z	    at async resolveConfig (file:///opt/buildhome/repo/node_modules/.pnpm/vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2_tsx@4.21.0_yaml@2.8.2/node_modules/vite/dist/node/chunks/config.js:35436:13)
2025-12-21T07:52:41.814Z	    at async createBuilder (file:///opt/buildhome/repo/node_modules/.pnpm/vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2_tsx@4.21.0_yaml@2.8.2/node_modules/vite/dist/node/chunks/config.js:33874:19)
2025-12-21T07:52:41.814Z	    at async CAC.<anonymous> (file:///opt/buildhome/repo/node_modules/.pnpm/vite@7.3.0_@types+node@22.19.3_jiti@2.6.1_lightningcss@1.30.2_tsx@4.21.0_yaml@2.8.2/node_modules/vite/dist/node/cli.js:629:10)
2025-12-21T07:52:41.904Z	 ELIFECYCLE  Command failed with exit code 1.
2025-12-21T07:52:41.925Z	Failed: error occurred while running build command