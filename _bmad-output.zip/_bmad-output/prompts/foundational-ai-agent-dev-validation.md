as I have progress through _bmad-output/sprint-artifacts/epic-25-12-28-master-implementation-plan.md can you coordinate dev-agent for *code-review of the completed stories and epics with the references of these sprint status and artifacts _bmad-output/sprint-artifacts/sprint-status.yaml 

```
_bmad-output/sprint-artifacts/12-1-create-agentfiletools-facade-context.xml
_bmad-output/sprint-artifacts/12-1-create-agentfiletools-facade.md
_bmad-output/sprint-artifacts/12-1b-add-concurrency-control-context.xml
_bmad-output/sprint-artifacts/12-1b-add-concurrency-control.md
_bmad-output/sprint-artifacts/12-2-create-agentterminaltools-facade-context.xml
_bmad-output/sprint-artifacts/12-2-create-agentterminaltools-facade.md
_bmad-output/sprint-artifacts/13-1-fix-terminal-working-directory-context.xml
_bmad-output/sprint-artifacts/13-1-fix-terminal-working-directory.md
_bmad-output/sprint-artifacts/13-2-fix-auto-sync-on-project-load-context.xml
_bmad-output/sprint-artifacts/13-2-fix-auto-sync-on-project-load.md
_bmad-output/sprint-artifacts/13-3-add-sync-progress-indicator-context.xml
_bmad-output/sprint-artifacts/13-3-add-sync-progress-indicator.md
_bmad-output/sprint-artifacts/13-4-preserve-file-tree-state-context.xml
_bmad-output/sprint-artifacts/13-4-preserve-file-tree-state.md
_bmad-output/sprint-artifacts/13-5-improve-permission-restoration-context.xml
_bmad-output/sprint-artifacts/13-5-improve-permission-restoration.md
_bmad-output/sprint-artifacts/13-6-fix-preview-in-new-tab-context.xml
_bmad-output/sprint-artifacts/13-6-fix-preview-in-new-tab.md
_bmad-output/sprint-artifacts/21-1-locale-aware-routing-and-html-lang-context.xml
_bmad-output/sprint-artifacts/21-1-locale-aware-routing-and-html-lang.md
_bmad-output/sprint-artifacts/21-3-language-switcher-and-persistence-context.xml
_bmad-output/sprint-artifacts/21-3-language-switcher-and-persistence.md
_bmad-output/sprint-artifacts/21-5-ui-migration-wave-2-ide-surfaces-context.xml
_bmad-output/sprint-artifacts/21-5-ui-migration-wave-2-ide-surfaces.md
_bmad-output/sprint-artifacts/21-8-complete-localization-coverage.md
_bmad-output/sprint-artifacts/22-1-implement-security-headers-context.xml
_bmad-output/sprint-artifacts/22-1-implement-security-headers.md
_bmad-output/sprint-artifacts/22-2-create-cicd-pipeline-context.xml
_bmad-output/sprint-artifacts/22-2-create-cicd-pipeline.md
_bmad-output/sprint-artifacts/22-3-add-integration-tests-context.xml
_bmad-output/sprint-artifacts/22-3-add-integration-tests.md
_bmad-output/sprint-artifacts/22-4-configure-error-monitoring-context.xml
_bmad-output/sprint-artifacts/22-4-configure-error-monitoring.md
_bmad-output/sprint-artifacts/22-5-create-deployment-docs-context.xml
_bmad-output/sprint-artifacts/22-5-create-deployment-docs.md
_bmad-output/sprint-artifacts/22-6-establish-performance-benchmarks.md
_bmad-output/sprint-artifacts/22-7-enable-typescript-strict.md
_bmad-output/sprint-artifacts/22-8-add-eslint-prettier.md
_bmad-output/sprint-artifacts/23-1-install-tailwindcss-4-context.xml
_bmad-output/sprint-artifacts/23-1-install-tailwindcss-4.md
_bmad-output/sprint-artifacts/23-2-initialize-shadcnui-context.xml
_bmad-output/sprint-artifacts/23-2-initialize-shadcnui.md
_bmad-output/sprint-artifacts/23-3-migrate-layout-components-context.xml
_bmad-output/sprint-artifacts/23-3-migrate-layout-components.md
_bmad-output/sprint-artifacts/23-4-migrate-ide-panel-components-context.xml
_bmad-output/sprint-artifacts/23-4-migrate-ide-panel-components.md
_bmad-output/sprint-artifacts/23-5-implement-theme-toggle-context.xml
_bmad-output/sprint-artifacts/23-5-implement-theme-toggle.md
_bmad-output/sprint-artifacts/25-0-create-provideradapterfactory-context.xml
_bmad-output/sprint-artifacts/25-0-create-provideradapterfactory.md
_bmad-output/sprint-artifacts/25-1-tanstack-ai-integration-setup-context.xml
_bmad-output/sprint-artifacts/25-1-tanstack-ai-integration-setup.md
_bmad-output/sprint-artifacts/25-2-implement-file-tools-context.xml
_bmad-output/sprint-artifacts/25-2-implement-file-tools.md
_bmad-output/sprint-artifacts/25-3-implement-terminal-tools-context.xml
_bmad-output/sprint-artifacts/25-3-implement-terminal-tools.md
_bmad-output/sprint-artifacts/25-4-wire-tool-execution-to-ui-context.xml
_bmad-output/sprint-artifacts/25-4-wire-tool-execution-to-ui.md
_bmad-output/sprint-artifacts/27-1-migrate-state-zustand-dexie-context.xml
_bmad-output/sprint-artifacts/27-1-migrate-state-zustand-dexie.md
_bmad-output/sprint-artifacts/27-1b-component-migration-zustand-dexie-context.xml
_bmad-output/sprint-artifacts/27-1b-component-migration-zustand-dexie.md
_bmad-output/sprint-artifacts/27-1c-persistence-migration-dexie-context.xml
_bmad-output/sprint-artifacts/27-1c-persistence-migration-dexie.md
_bmad-output/sprint-artifacts/27-2-event-bus-integration-context.xml
_bmad-output/sprint-artifacts/27-2-event-bus-integration.md
_bmad-output/sprint-artifacts/27-5a-refactor-idelayout-context.xml
_bmad-output/sprint-artifacts/27-5a-refactor-idelayout.md
_bmad-output/sprint-artifacts/27-I-complete-state-integration-context.xml
_bmad-output/sprint-artifacts/27-I-complete-state-integration.md
_bmad-output/sprint-artifacts/28-1-override-design-tokens.md
_bmad-output/sprint-artifacts/28-2-configure-8bit-typography.md
_bmad-output/sprint-artifacts/28-13-full-ui-integration-audit.md
_bmad-output/sprint-artifacts/28-14-wire-icon-sidebar.md
_bmad-output/sprint-artifacts/28-16-agent-config-flow-context.xml
_bmad-output/sprint-artifacts/28-16-agent-config-flow.md
_bmad-output/sprint-artifacts/28-18-statusbar-connection-indicators-context.xml
_bmad-output/sprint-artifacts/28-18-statusbar-connection-indicators.md
_bmad-output/sprint-artifacts/28-19-chat-tool-call-badge-context.xml
_bmad-output/sprint-artifacts/28-19-chat-tool-call-badge.md
_bmad-output/sprint-artifacts/28-20-chat-code-block-with-actions-context.xml
_bmad-output/sprint-artifacts/28-20-chat-code-block-with-actions.md
_bmad-output/sprint-artifacts/28-21-diff-preview-component-context.xml
_bmad-output/sprint-artifacts/28-21-diff-preview-component.md
_bmad-output/sprint-artifacts/28-22-approval-overlay-component-context.xml
_bmad-output/sprint-artifacts/28-22-approval-overlay-component.md
_bmad-output/sprint-artifacts/28-23-streaming-message-container-context.xml
_bmad-output/sprint-artifacts/28-23-streaming-message-container.md
```
---
As we are moving towards to integration points and  preparing for my actual real-life use cases end to end test -> I suggest for thorough validation so far -> conduct research and propose any *correct-course and *remediation workflows as needed 

## Check if these concerns resolved 

```
_bmad-output/sprint-artifacts/epic-25-11-06-research-analysis-request.md
_bmad-output/sprint-artifacts/epic-25-12-06-openaicompatible-support.md
_bmad-output/sprint-artifacts/epic-25-12-06-multilingual-ai-agent-support.md
```

## Epic 27 and 28 concerns 
as mentioned and investigated here 
```
docs/2025-12-23/tech-debt.md
docs/2025-12-23/improvement-opportunities.md

```

Should we also start to address epic 27?

---

# SOME CONTEXT FOR YOUR REFERENCES


## Master plan, research guidance (use @web and MCP tools as needed during and in between the iterations as needed) , route accordingly 

```
_bmad-output\sprint-artifacts\epic-25-12-28-master-implementation-plan.md
_bmad-output\sprint-artifacts\epic-25-12-28-readiness-analysis.md
_bmad-output\sprint-artifacts\epic-25-11-06-research-analysis-request.md

```

@sprint-status.yaml 

## These are the architecture and structure of the project 

```
docs\2025-12-23
docs\2025-12-23\architecture.md
docs\2025-12-23\data-and-contracts.md
docs\2025-12-23\flows-and-workflows.md
docs\2025-12-23\structure-map.md
docs\2025-12-23\tech-context.md
```
- Refer to these for quick context 
- update them when there are changes in any 

## Use development guidelines at @AGENTS.md for development

- also make sure to keep packages at latest compatible versions (especial the Tanstack AI packages ; and their ecosystem packages which are all at alpha stages so versions update are quite frequent)

## DO NOT USE YOUR INNATE IMPLEMENTATION PLAN - USE BMAD FRAMEWORK AND UPDATE ON WHAT I HAVE PROVIDED ABOVE

---

## in-depth Tanstack AI knowledge regarding tools, agentic loops etc (use @web and MCP servers' tools as Context7, Deepwiki, Tavily, Exa, Repomix to fetch these knowledge)

- https://tanstack.com/ai/latest/docs/guides/client-tools

- https://tanstack.com/ai/latest/docs/guides/server-tools

- https://tanstack.com/ai/latest/docs/guides/tool-architecture

- https://tanstack.com/ai/latest/docs/guides/tool-approval 

- https://tanstack.com/ai/latest/docs/guides/agentic-cycle

- https://tanstack.com/ai/latest/docs/guides/connection-adapters 

- https://tanstack.com/ai/latest/docs/api/ai-client

- https://tanstack.com/ai/latest/docs/api/ai-react 

- https://tanstack.com/ai/latest/docs/reference/functions/

## TANSTACK AI  API, methods, classes, types, interfaces, alias references index

```
Perfect! I can now extract and organize all the documentation links. Let me create a comprehensive index of all the links organized by category.

Based on the TanStack AI documentation structure, here's a complete index of all documentation links organized by category:

## API

- [@tanstack/ai](https://tanstack.com/ai/latest/docs/api/ai)
- [@tanstack/ai-client](https://tanstack.com/ai/latest/docs/api/ai-client)
- [@tanstack/ai-react](https://tanstack.com/ai/latest/docs/api/ai-react)
- [@tanstack/ai-solid](https://tanstack.com/ai/latest/docs/api/ai-solid)

## ADAPTERS

- [OpenAI](https://tanstack.com/ai/latest/docs/adapters/openai)
- [Anthropic](https://tanstack.com/ai/latest/docs/adapters/anthropic)
- [Google Gemini](https://tanstack.com/ai/latest/docs/adapters/gemini)
- [Ollama](https://tanstack.com/ai/latest/docs/adapters/ollama)

## CLASS REFERENCES

- [BaseAdapter](https://tanstack.com/ai/latest/docs/reference/classes/BaseAdapter)
- [BatchStrategy](https://tanstack.com/ai/latest/docs/reference/classes/BatchStrategy)
- [CompositeStrategy](https://tanstack.com/ai/latest/docs/reference/classes/CompositeStrategy)
- [ImmediateStrategy](https://tanstack.com/ai/latest/docs/reference/classes/ImmediateStrategy)
- [PartialJSONParser](https://tanstack.com/ai/latest/docs/reference/classes/PartialJSONParser)
- [PunctuationStrategy](https://tanstack.com/ai/latest/docs/reference/classes/PunctuationStrategy)
- [StreamProcessor](https://tanstack.com/ai/latest/docs/reference/classes/StreamProcessor)
- [ToolCallManager](https://tanstack.com/ai/latest/docs/reference/classes/ToolCallManager)
- [WordBoundaryStrategy](https://tanstack.com/ai/latest/docs/reference/classes/WordBoundaryStrategy)

## FUNCTION REFERENCES

- [text](https://tanstack.com/ai/latest/docs/reference/functions/text)
- [textOptions](https://tanstack.com/ai/latest/docs/reference/functions/textOptions)
- [combineStrategies](https://tanstack.com/ai/latest/docs/reference/functions/combineStrategies)
- [convertMessagesToModelMessages](https://tanstack.com/ai/latest/docs/reference/functions/convertMessagesToModelMessages)
- [convertZodToJsonSchema](https://tanstack.com/ai/latest/docs/reference/functions/convertZodToJsonSchema)
- [createReplayStream](https://tanstack.com/ai/latest/docs/reference/functions/createReplayStream)
- [embedding](https://tanstack.com/ai/latest/docs/reference/functions/embedding)
- [generateMessageId](https://tanstack.com/ai/latest/docs/reference/functions/generateMessageId)
- [maxIterations](https://tanstack.com/ai/latest/docs/reference/functions/maxIterations)
- [messages](https://tanstack.com/ai/latest/docs/reference/functions/messages)
- [modelMessageToUIMessage](https://tanstack.com/ai/latest/docs/reference/functions/modelMessageToUIMessage)
- [modelMessagesToUIMessages](https://tanstack.com/ai/latest/docs/reference/functions/modelMessagesToUIMessages)
- [normalizeToUIMessage](https://tanstack.com/ai/latest/docs/reference/functions/normalizeToUIMessage)
- [parsePartialJSON](https://tanstack.com/ai/latest/docs/reference/functions/parsePartialJSON)
- [summarize](https://tanstack.com/ai/latest/docs/reference/functions/summarize)
- [toServerSentEventsStream](https://tanstack.com/ai/latest/docs/reference/functions/toServerSentEventsStream)
- [toStreamResponse](https://tanstack.com/ai/latest/docs/reference/functions/toStreamResponse)
- [toolDefinition](https://tanstack.com/ai/latest/docs/reference/functions/toolDefinition)
- [uiMessageToModelMessages](https://tanstack.com/ai/latest/docs/reference/functions/uiMessageToModelMessages)
- [untilFinishReason](https://tanstack.com/ai/latest/docs/reference/functions/untilFinishReason)

## INTERFACE REFERENCES

- [AIAdapter](https://tanstack.com/ai/latest/docs/reference/interfaces/AIAdapter)
- [AIAdapterConfig](https://tanstack.com/ai/latest/docs/reference/interfaces/AIAdapterConfig)
- [AgentLoopState](https://tanstack.com/ai/latest/docs/reference/interfaces/AgentLoopState)
- [ApprovalRequestedStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ApprovalRequestedStreamChunk)
- [AudioPart](https://tanstack.com/ai/latest/docs/reference/interfaces/AudioPart)
- [BaseStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/BaseStreamChunk)
- [TextCompletionChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/TextCompletionChunk)
- [TextOptions](https://tanstack.com/ai/latest/docs/reference/interfaces/TextOptions)
- [ChunkRecording](https://tanstack.com/ai/latest/docs/reference/interfaces/ChunkRecording)
- [ChunkStrategy](https://tanstack.com/ai/latest/docs/reference/interfaces/ChunkStrategy)
- [ClientTool](https://tanstack.com/ai/latest/docs/reference/interfaces/ClientTool)
- [ContentPartSource](https://tanstack.com/ai/latest/docs/reference/interfaces/ContentPartSource)
- [ContentStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ContentStreamChunk)
- [DefaultMessageMetadataByModality](https://tanstack.com/ai/latest/docs/reference/interfaces/DefaultMessageMetadataByModality)
- [DocumentPart](https://tanstack.com/ai/latest/docs/reference/interfaces/DocumentPart)
- [DoneStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/DoneStreamChunk)
- [EmbeddingOptions](https://tanstack.com/ai/latest/docs/reference/interfaces/EmbeddingOptions)
- [EmbeddingResult](https://tanstack.com/ai/latest/docs/reference/interfaces/EmbeddingResult)
- [ErrorStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ErrorStreamChunk)
- [ImagePart](https://tanstack.com/ai/latest/docs/reference/interfaces/ImagePart)
- [InternalToolCallState](https://tanstack.com/ai/latest/docs/reference/interfaces/InternalToolCallState)
- [JSONParser](https://tanstack.com/ai/latest/docs/reference/interfaces/JSONParser)
- [ModelMessage](https://tanstack.com/ai/latest/docs/reference/interfaces/ModelMessage)
- [ProcessorResult](https://tanstack.com/ai/latest/docs/reference/interfaces/ProcessorResult)
- [ProcessorState](https://tanstack.com/ai/latest/docs/reference/interfaces/ProcessorState)
- [ResponseFormat](https://tanstack.com/ai/latest/docs/reference/interfaces/ResponseFormat)
- [ServerTool](https://tanstack.com/ai/latest/docs/reference/interfaces/ServerTool)
- [StreamProcessorEvents](https://tanstack.com/ai/latest/docs/reference/interfaces/StreamProcessorEvents)
- [StreamProcessorHandlers](https://tanstack.com/ai/latest/docs/reference/interfaces/StreamProcessorHandlers)
- [StreamProcessorOptions](https://tanstack.com/ai/latest/docs/reference/interfaces/StreamProcessorOptions)
- [SummarizationOptions](https://tanstack.com/ai/latest/docs/reference/interfaces/SummarizationOptions)
- [SummarizationResult](https://tanstack.com/ai/latest/docs/reference/interfaces/SummarizationResult)
- [TextPart](https://tanstack.com/ai/latest/docs/reference/interfaces/TextPart)
- [ThinkingPart](https://tanstack.com/ai/latest/docs/reference/interfaces/ThinkingPart)
- [ThinkingStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ThinkingStreamChunk)
- [Tool](https://tanstack.com/ai/latest/docs/reference/interfaces/Tool)
- [ToolCall](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolCall)
- [ToolCallPart](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolCallPart)
- [ToolCallStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolCallStreamChunk)
- [ToolConfig](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolConfig)
- [ToolDefinition](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolDefinition)
- [ToolDefinitionConfig](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolDefinitionConfig)
- [ToolDefinitionInstance](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolDefinitionInstance)
- [ToolInputAvailableStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolInputAvailableStreamChunk)
- [ToolResultPart](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolResultPart)
- [ToolResultStreamChunk](https://tanstack.com/ai/latest/docs/reference/interfaces/ToolResultStreamChunk)
- [UIMessage](https://tanstack.com/ai/latest/docs/reference/interfaces/UIMessage)
- [VideoPart](https://tanstack.com/ai/latest/docs/reference/interfaces/VideoPart)

## TYPE ALIAS REFERENCES

- [AgentLoopStrategy](https://tanstack.com/ai/latest/docs/reference/type-aliases/AgentLoopStrategy)
- [AnyClientTool](https://tanstack.com/ai/latest/docs/reference/type-aliases/AnyClientTool)
- [TextStreamOptionsForModel](https://tanstack.com/ai/latest/docs/reference/type-aliases/TextStreamOptionsForModel)
- [TextStreamOptionsUnion](https://tanstack.com/ai/latest/docs/reference/type-aliases/TextStreamOptionsUnion)
- [ConstrainedContent](https://tanstack.com/ai/latest/docs/reference/type-aliases/ConstrainedContent)
- [ConstrainedModelMessage](https://tanstack.com/ai/latest/docs/reference/type-aliases/ConstrainedModelMessage)
- [ContentPart](https://tanstack.com/ai/latest/docs/reference/type-aliases/ContentPart)
- [ContentPartForModalities](https://tanstack.com/ai/latest/docs/reference/type-aliases/ContentPartForModalities)
- [ExtractModalitiesForModel](https://tanstack.com/ai/latest/docs/reference/type-aliases/ExtractModalitiesForModel)
- [ExtractModelsFromAdapter](https://tanstack.com/ai/latest/docs/reference/type-aliases/ExtractModelsFromAdapter)
- [InferToolInput](https://tanstack.com/ai/latest/docs/reference/type-aliases/InferToolInput)
- [InferToolName](https://tanstack.com/ai/latest/docs/reference/type-aliases/InferToolName)
- [InferToolOutput](https://tanstack.com/ai/latest/docs/reference/type-aliases/InferToolOutput)
- [MessagePart](https://tanstack.com/ai/latest/docs/reference/type-aliases/MessagePart)
- [ModalitiesArrayToUnion](https://tanstack.com/ai/latest/docs/reference/type-aliases/ModalitiesArrayToUnion)
- [Modality](https://tanstack.com/ai/latest/docs/reference/type-aliases/Modality)
- [StreamChunk](https://tanstack.com/ai/latest/docs/reference/type-aliases/StreamChunk)
- [StreamChunkType](https://tanstack.com/ai/latest/docs/reference/type-aliases/StreamChunkType)
- [ToolCallState](https://tanstack.com/ai/latest/docs/reference/type-aliases/ToolCallState)
- [ToolResultState](https://tanstack.com/ai/latest/docs/reference/type-aliases/ToolResultState)

## VARIABLE REFERENCES

- [aiEventClient](https://tanstack.com/ai/latest/docs/reference/variables/aiEventClient)
- [defaultJSONParser](https://tanstack.com/ai/latest/docs/reference/variables/defaultJSONParser)

***

**Summary:** This index contains 126 total documentation links across 7 main categories: 4 API packages, 4 adapters, 9 classes, 20 functions, 48 interfaces, 20 type aliases, and 2 variables. All links follow the pattern https://tanstack.com/ai/latest/docs/... and are part of the TanStack AI library documentation.[1]



## **ULTRA IMPORTANT** notices:
As this sequence of epics and stories are extremely intricate and mutually complex and due to we need to iterate, on trials and errors, as well as scaffolding these, I highly anticipate you to ultrathink everytime -> to detect flaws, inaccuracy (as cross-dependencies, cross-architectures issues of these rather new stacks when they work together for advanced features such as tools, loops, agentic loops, that AI agents must be able to perform CRUD operations to many other slices of this project - 100% client-side)

- Meaning you must always ready to work cross-stories, cross-epics -> research and investigate as errors, bugs occur. Do not just look at one single story scope.

---
Use MCP servers tools to help you - delegaate agents and sub-agents as you see fit. Iterate through multiple cycles, make use of your system of SKILLS, commands, plugins. Give me recommendations for what next