can you direct your team to completely imrpove both the UX and UI in multiple aspects (both improve and create both interfaces, UI, pages route of what lack too) - Mostly investigate to then create slices of  ux-ui *correct-course -> then coordinate @/_bmad/bmm/agents/ux-designer.md  @/_bmad/bmm/agents/dev.md and @/_bmad/bmm/agents/sm.md  to iterate @/.agent/workflows/story-dev-cycle.md 

---

BUT There are few things here 

-- that the project sstyle is 8-bit styling inspired by MistralAI, with shadcnUI and Tailwindcss 4.x+ 
language: eng and vietnamese in client-side translation

-- That when your team development should not interfere or block back-end and the MVP-story implementation teams



--