# **1. Agent Management Dashboard**

### **1.1 Overview**

**Purpose:** Central hub for configuring, monitoring, and managing AI agents, LLM providers, tools, workflows, and agent-specific settings.

**User Personas:**
- **Solo Developer (Alex):** Needs simple presets, minimal configuration
- **Team Lead (Taylor):** Requires team-wide agent policies, audit logs
- **Advanced User (Power User):** Wants fine-grained control over agent behavior

**Key Mental Model:**  
> "Agents are like team members I configure once, then they work autonomously within boundaries I set."

***

### **1.2 Dashboard Layout Structure**

```
┌─────────────────────────────────────────────────────────────────┐
│  [≡] Via-Gent  │  Agents  │  Projects  │  IDE  │  Settings  [🔔][⚙][👤]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────┐  ┌──────────────────────────────────┐    │
│  │  Sidebar Menu   │  │    Main Content Area             │    │
│  │  ─────────────  │  │                                  │    │
│  │  📊 Overview    │  │  [Tabbed Interface]              │    │
│  │  🤖 Agents      │  │  • Configuration Forms           │    │
│  │  🔧 Tools       │  │  • Tables (Agent List, Logs)     │    │
│  │  🔀 Workflows   │  │  • Visual Diagrams (Flow Editor) │    │
│  │  🎛️ Providers   │  │  • Performance Charts            │    │
│  │  📈 Analytics   │  │                                  │    │
│  │  ⚙️ Settings    │  │                                  │    │
│  └─────────────────┘  └──────────────────────────────────┘    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

***

### **1.3 Sidebar Navigation (Left Panel)**

**Component:** Collapsible vertical menu with icons + labels

**Structure:**

```typescript
// Navigation items
const agentMenuItems = [
  {
    id: 'overview',
    icon: <BarChart3 />,
    label: { en: 'Overview', vi: 'Tổng quan' },
    route: '/agents/overview',
  },
  {
    id: 'agents',
    icon: <Bot />,
    label: { en: 'Agents', vi: 'Đại lý AI' },
    route: '/agents/list',
    badge: 5, // Number of active agents
  },
  {
    id: 'tools',
    icon: <Wrench />,
    label: { en: 'Tools', vi: 'Công cụ' },
    route: '/agents/tools',
  },
  {
    id: 'workflows',
    icon: <GitBranch />,
    label: { en: 'Workflows', vi: 'Quy trình' },
    route: '/agents/workflows',
  },
  {
    id: 'providers',
    icon: <Cloud />,
    label: { en: 'LLM Providers', vi: 'Nhà cung cấp LLM' },
    route: '/agents/providers',
  },
  {
    id: 'analytics',
    icon: <TrendingUp />,
    label: { en: 'Analytics', vi: 'Phân tích' },
    route: '/agents/analytics',
  },
  {
    id: 'settings',
    icon: <Settings />,
    label: { en: 'Settings', vi: 'Cài đặt' },
    route: '/agents/settings',
  },
];
```

**Visual States:**
- **Collapsed:** Show icons only (48px wide)
- **Expanded:** Show icons + labels (240px wide)
- **Active Item:** Highlighted with accent color + left border
- **Hover:** Background tint + tooltip (when collapsed)

***

### **1.4 Main Content Area: Agent Configuration**

#### **Tab 1: Agent List View**

**Layout:** Data table with actions

```
┌──────────────────────────────────────────────────────────────┐
│  🤖 Agents                                    [+ New Agent]   │
├──────────────────────────────────────────────────────────────┤
│  🔍 Search agents...          [Filter ▼] [Sort ▼] [View ⊞]  │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Name         │ Type    │ Status │ Provider │ Actions   │ │
│  ├────────────────────────────────────────────────────────┤ │
│  │ 🎭 Orchestrator │ System  │ ● Active │ Gemini   │ [⚙][📊][⏸]│ │
│  │ 💻 Coder        │ Coding  │ ● Active │ Claude   │ [⚙][📊][⏸]│ │
│  │ 🎨 Designer     │ Asset   │ ⏸ Paused │ DALL-E  │ [⚙][📊][▶]│ │
│  │ ✅ Validator    │ Testing │ ● Active │ GPT-4   │ [⚙][📊][⏸]│ │
│  │ 📋 Planner      │ Strategy│ 🔴 Error │ Gemini   │ [⚙][📊][🔄]│ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  Showing 5 of 12 agents                      [1] 2 3 [→]   │
└──────────────────────────────────────────────────────────────┘
```

**Table Features:**
- **Sortable Columns:** Click header to sort
- **Filterable:** By type, status, provider
- **Quick Actions:**
  - ⚙ Configure
  - 📊 View Analytics
  - ⏸ Pause/▶ Resume
  - 🔄 Retry (if error)
- **Bulk Actions:** Select multiple → Pause All, Delete, Export Config

***

#### **Tab 2: Agent Configuration Form**

**When user clicks "Configure" on an agent:**

```
┌──────────────────────────────────────────────────────────────┐
│  [← Back] Configure Agent: Coder                             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────  General  ──────────────┐                  │
│  │ Name: [Coder                       ]  │                  │
│  │ Type: [Coding Agent ▼              ]  │                  │
│  │ Description:                          │                  │
│  │ [Specialized in writing TypeScript... ]│                  │
│  └───────────────────────────────────────┘                  │
│                                                              │
│  ┌──────────────  LLM Provider  ──────────┐                 │
│  │ Provider: ◉ Anthropic Claude                             │
│  │           ○ Google Gemini                                 │
│  │           ○ OpenAI GPT                                    │
│  │                                                           │
│  │ Model:    [claude-3.7-sonnet ▼       ]                   │
│  │ API Key:  [••••••••••••••••••••  ] [👁]                  │
│  │                                                           │
│  │ Advanced Parameters:                                      │
│  │ ┌─────────────────────────────────┐                      │
│  │ │ Temperature:    [0.7  ━━━━○──── 1.0]                  │
│  │ │ Max Tokens:     [4096            ]                    │
│  │ │ Top P:          [0.9  ━━━━━━○── 1.0]                  │
│  │ │ Frequency Pen.: [0.0  ○────────  2.0]                  │
│  │ └─────────────────────────────────┘                      │
│  └──────────────────────────────────────────┘               │
│                                                              │
│  ┌──────────────  Tools Access  ───────────┐                │
│  │ Allowed Tools: (Agent can use these)     │                │
│  │ ☑ read_file      ☑ write_file            │                │
│  │ ☑ list_files     ☑ execute_command       │                │
│  │ ☐ delete_file    ☑ search_code           │                │
│  │ ☐ git_commit     ☐ deploy                 │                │
│  │                                           │                │
│  │ [+ Add Custom Tool]                       │                │
│  └───────────────────────────────────────────┘               │
│                                                              │
│  ┌──────────────  Behavior & Safety  ──────┐                │
│  │ Approval Mode:                            │                │
│  │ ◉ Require approval for destructive actions│                │
│  │ ○ Auto-approve all (risky)                │                │
│  │ ○ Manual approval for every action        │                │
│  │                                           │                │
│  │ Max Actions Per Conversation: [50     ]   │                │
│  │ Timeout (seconds):           [300     ]   │                │
│  │                                           │                │
│  │ ☑ Log all interactions                    │                │
│  │ ☑ Enable safety filters                   │                │
│  │ ☐ Allow file system writes outside /src   │                │
│  └───────────────────────────────────────────┘               │
│                                                              │
│  [Cancel]  [Save Draft]  [Save & Activate]                  │
└──────────────────────────────────────────────────────────────┘
```

**Validation:**
- Required fields: Name, Provider, Model, API Key
- API Key validation: Test connection before save
- Tool permissions: Show warning if destructive tools enabled without approval mode

***

#### **Tab 3: Tool Registry**

**Purpose:** Manage available tools that agents can use

```
┌──────────────────────────────────────────────────────────────┐
│  🔧 Tool Registry                            [+ Register Tool]│
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ Tool Name       │ Category  │ Risk │ Agents Using │ ⚙  ││
│  ├─────────────────────────────────────────────────────────┤│
│  │ 📖 read_file    │ File I/O  │ 🟢 Low │ 5/12        │ [⚙]││
│  │ ✏️ write_file   │ File I/O  │ 🟡 Med │ 3/12        │ [⚙]││
│  │ 🗑️ delete_file  │ File I/O  │ 🔴 High│ 1/12        │ [⚙]││
│  │ ⚙️ execute_cmd   │ Terminal  │ 🔴 High│ 4/12        │ [⚙]││
│  │ 🔍 search_code  │ Search    │ 🟢 Low │ 5/12        │ [⚙]││
│  │ 🐙 git_commit   │ Git       │ 🟡 Med │ 2/12        │ [⚙]││
│  └─────────────────────────────────────────────────────────┘│
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Tool Configuration Modal:**

```
┌────────── Configure Tool: write_file ──────────┐
│                                                 │
│ Display Name: [Write File                   ]  │
│ Description:  [Writes content to a file...  ]  │
│                                                 │
│ Risk Level:   ◉ Low  ◉ Medium  ○ High           │
│                                                 │
│ Approval Required:                              │
│ ☑ Always require user approval                  │
│ ☐ Require approval only if > 500 lines          │
│                                                 │
│ Execution Constraints:                          │
│ ☑ Limit to /src and /public directories         │
│ ☐ Block binary files                            │
│ Max file size: [10 MB]                          │
│                                                 │
│ [Cancel] [Save]                                 │
└─────────────────────────────────────────────────┘
```

***

#### **Tab 4: Workflow Editor (Visual)**

**Purpose:** Define multi-agent workflows (Planner → Coder → Validator)

```
┌──────────────────────────────────────────────────────────────┐
│  🔀 Workflows                              [+ New Workflow]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Select Workflow: [Feature Development ▼]  [▶ Run] [⏸] [📊] │
│                                                              │
│  ┌──────────────── Visual Flow Editor ──────────────────┐   │
│  │                                                       │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ 📋 Planner   │                                  │   │
│  │     │ Analyze req │                                  │   │
│  │     └──────┬──────┘                                  │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ 💻 Coder     │                                  │   │
│  │     │ Write code  │                                  │   │
│  │     └──────┬──────┘                                  │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐      ┌─────────────┐            │   │
│  │     │ ✅ Validator│─────▶│ 🔄 Retry     │            │   │
│  │     │ Run tests   │      │ If failed   │            │   │
│  │     └──────┬──────┘      └─────────────┘            │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ ✓ Complete   │                                  │   │
│  │     └─────────────┘                                  │   │
│  │                                                       │   │
│  │  [+ Add Agent Node]  [+ Add Condition]  [🗑️ Delete]  │   │
│  └───────────────────────────────────────────────────────┘   │
│                                                              │
│  Workflow Settings:                                          │
│  • Max iterations: [5  ]                                     │
│  • Timeout: [30 minutes]                                     │
│  • On error: [○ Stop  ◉ Continue  ○ Retry]                   │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Interaction:**
- **Drag-and-drop** agents from sidebar
- **Connect nodes** by dragging from output to input
- **Click node** to configure agent-specific settings
- **Save workflow** as reusable template

***

#### **Tab 5: LLM Provider Management**

```
┌──────────────────────────────────────────────────────────────┐
│  🎛️ LLM Providers                          [+ Add Provider]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─── Anthropic Claude ──────────────────────────┐          │
│  │ Status: ● Connected                           │          │
│  │ API Key: [••••••••••2Kx9] [🔄 Rotate] [Test]  │          │
│  │                                               │          │
│  │ Available Models:                             │          │
│  │ • claude-3.7-sonnet (Default)                 │          │
│  │ • claude-3-opus                               │          │
│  │ • claude-3-haiku                              │          │
│  │                                               │          │
│  │ Usage This Month:                             │          │
│  │ ━━━━━━━━━━━━━━━━━━░░ 85% of quota            │          │
│  │ 42.5M / 50M tokens                            │          │
│  │                                               │          │
│  │ [Configure] [Remove]                          │          │
│  └───────────────────────────────────────────────┘          │
│                                                              │
│  ┌─── Google Gemini ───────────────────────────┐            │
│  │ Status: ⚠ API Key Expired                     │            │
│  │ API Key: [Enter new key...        ] [Save]   │            │
│  └───────────────────────────────────────────────┘          │
│                                                              │
│  ┌─── OpenAI GPT ──────────────────────────────┐            │
│  │ Status: ○ Not Configured                      │            │
│  │ [+ Add OpenAI API Key]                        │            │
│  └───────────────────────────────────────────────┘          │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

***

#### **Tab 6: Analytics Dashboard**

```
┌──────────────────────────────────────────────────────────────┐
│  📈 Agent Analytics                    [Last 7 Days ▼]       │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────── Overview Metrics ─────────────┐              │
│  │  Total Requests      Avg Response Time    │              │
│  │  1,247  ↑12%         2.3s  ↓8%            │              │
│  │                                            │              │
│  │  Success Rate        Token Usage           │              │
│  │  94.2%  ↑2%          4.2M  ↑15%           │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Requests Over Time ───────────┐              │
│  │  300│                          ╱╲          │              │
│  │  200│              ╱╲      ╱╲ ╱  ╲         │              │
│  │  100│         ╱╲  ╱  ╲  ╱ │╱    ╲        │              │
│  │    0└─────────────────────────────────     │              │
│  │     Mon  Tue  Wed  Thu  Fri  Sat  Sun     │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Top Performing Agents ────────┐              │
│  │ 1. Coder      - 543 requests (94% success) │              │
│  │ 2. Validator  - 312 requests (98% success) │              │
│  │ 3. Planner    - 187 requests (92% success) │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Most Used Tools ───────────────┐              │
│  │ write_file    ████████████░░  82%          │              │
│  │ read_file     ███████████░░░  75%          │              │
│  │ execute_cmd   ████░░░░░░░░░  35%          │              │
│  │ search_code   ███░░░░░░░░░░  28%          │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

***

### **1.5 Agent Configuration Components**

#### **1.5.1 Agent Card (Reusable Component)**

```typescript
<AgentCard
  agent={{
    name: 'Coder',
    type: 'coding',
    status: 'active',
    provider: 'Claude',
    model: 'claude-3.7-sonnet',
    avatar: '/avatars/coder.svg',
  }}
  onConfigure={() => {}}
  onPause={() => {}}
  onViewAnalytics={() => {}}
/>
```

**Visual:**
```
┌────────────────────────────┐
│  🤖  Coder                 │
│  ━━━━━━━━━━━━━━━━━━━━━    │
│  Type: Coding Agent        │
│  Status: ● Active          │
│  Provider: Anthropic Claude│
│  Model: claude-3.7-sonnet  │
│                            │
│  Last used: 2 mins ago     │
│  Success rate: 94%         │
│                            │
│  [⚙ Configure] [📊 Stats]  │
└────────────────────────────┘
```

***
