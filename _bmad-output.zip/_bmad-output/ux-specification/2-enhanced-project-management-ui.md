# **2. Enhanced Project Management UI**

### **2.1 Dashboard Improvements**

**Current Issue:** Generic project cards with minimal info

**Enhanced Version:**

```
┌──────────────────────────────────────────────────────────────┐
│  📁 Projects                    [+ New Project] [Import]     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────┐  ┌─────────────────────┐          │
│  │ 📦 via-gent         │  │ 🚀 ecommerce-app    │          │
│  │ ━━━━━━━━━━━━━━━━━━ │  │ ━━━━━━━━━━━━━━━━━━ │          │
│  │ Last edited: 5m ago │  │ Last edited: 2h ago │          │
│  │ Status: ● Running   │  │ Status: ○ Stopped   │          │
│  │                     │  │                     │          │
│  │ 📊 Activity:        │  │ 📊 Activity:        │          │
│  │ • 12 files changed  │  │ • 3 files changed   │          │
│  │ • 2 commits         │  │ • 0 commits         │          │
│  │ • 5 AI requests     │  │ • 1 AI request      │          │
│  │                     │  │                     │          │
│  │ 🤖 Active Agents:   │  │ 🤖 Active Agents:   │          │
│  │ Coder, Validator    │  │ None                │          │
│  │                     │  │                     │          │
│  │ [Open] [Settings]   │  │ [Open] [Archive]    │          │
│  └─────────────────────┘  └─────────────────────┘          │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Key Additions:**
- **Real-time status** (dev server running?)
- **Activity summary** (files changed, commits, AI usage)
- **Active agents** indicator
- **Quick actions** (Open, Settings, Archive)

***

### **2.2 Project Settings Deep Dive**

**When clicking "Settings" on a project:**

```
┌──────────── Project: via-gent Settings ──────────┐
│                                                   │
│  [General] [Build] [Agents] [Git] [Deploy]       │
│                                                   │
│  ┌──────────── General ─────────────┐            │
│  │ Project Name: [via-gent      ]   │            │
│  │ Description:  [AI-powered IDE... ]│            │
│  │ Root Path:    [/Users/...via-gent]│            │
│  │                                   │            │
│  │ Framework: [TanStack Start ▼  ]  │            │
│  │ Package Manager: [pnpm ▼      ]  │            │
│  └───────────────────────────────────┘            │
│                                                   │
│  ┌──────────── Agents ──────────────┐            │
│  │ Enabled Agents: (Project-specific)│            │
│  │ ☑ Coder      ☑ Validator          │            │
│  │ ☑ Planner    ☐ Designer           │            │
│  │                                   │            │
│  │ Agent Presets:                    │            │
│  │ ○ Minimal (Coder only)            │            │
│  │ ◉ Standard (Coder + Validator)     │            │
│  │ ○ Full Team (All agents)          │            │
│  └───────────────────────────────────┘            │
│                                                   │
│  [Cancel] [Save]                                  │
└───────────────────────────────────────────────────┘
```

***
