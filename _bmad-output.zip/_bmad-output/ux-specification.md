

# 🎨 **Via-Gent Agent Management & Configuration - Complete UX Specification**

**Document Version:** 2.0  
**Date:** December 21, 2025  
**Languages:** EN (English) | VI (Vietnamese)  
**Target:** MVP → Full Production

***

## 📋 **Table of Contents**

1. [Agent Management Dashboard](#1-agent-management-dashboard)
2. [Enhanced Project Management UI](#2-enhanced-project-management-ui)
3. [Unified IDE Workspace with Collapsible Sidebar](#3-unified-ide-workspace)
4. [Robust Agent Chat Interface](#4-robust-agent-chat-interface)
5. [Component Library & Design System](#5-component-library)
6. [Responsive Layouts & Navigation](#6-responsive-layouts)
7. [i18n Implementation Guide](#7-i18n-implementation)

***

## **1. Agent Management Dashboard**

### **1.1 Overview**

**Purpose:** Central hub for configuring, monitoring, and managing AI agents, LLM providers, tools, workflows, and agent-specific settings.

**User Personas:**
- **Solo Developer (Alex):** Needs simple presets, minimal configuration
- **Team Lead (Taylor):** Requires team-wide agent policies, audit logs
- **Advanced User (Power User):** Wants fine-grained control over agent behavior

**Key Mental Model:**  
> "Agents are like team members I configure once, then they work autonomously within boundaries I set."

***

### **1.2 Dashboard Layout Structure**

```
┌─────────────────────────────────────────────────────────────────┐
│  [≡] Via-Gent  │  Agents  │  Projects  │  IDE  │  Settings  [🔔][⚙][👤]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────┐  ┌──────────────────────────────────┐    │
│  │  Sidebar Menu   │  │    Main Content Area             │    │
│  │  ─────────────  │  │                                  │    │
│  │  📊 Overview    │  │  [Tabbed Interface]              │    │
│  │  🤖 Agents      │  │  • Configuration Forms           │    │
│  │  🔧 Tools       │  │  • Tables (Agent List, Logs)     │    │
│  │  🔀 Workflows   │  │  • Visual Diagrams (Flow Editor) │    │
│  │  🎛️ Providers   │  │  • Performance Charts            │    │
│  │  📈 Analytics   │  │                                  │    │
│  │  ⚙️ Settings    │  │                                  │    │
│  └─────────────────┘  └──────────────────────────────────┘    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

***

### **1.3 Sidebar Navigation (Left Panel)**

**Component:** Collapsible vertical menu with icons + labels

**Structure:**

```typescript
// Navigation items
const agentMenuItems = [
  {
    id: 'overview',
    icon: <BarChart3 />,
    label: { en: 'Overview', vi: 'Tổng quan' },
    route: '/agents/overview',
  },
  {
    id: 'agents',
    icon: <Bot />,
    label: { en: 'Agents', vi: 'Đại lý AI' },
    route: '/agents/list',
    badge: 5, // Number of active agents
  },
  {
    id: 'tools',
    icon: <Wrench />,
    label: { en: 'Tools', vi: 'Công cụ' },
    route: '/agents/tools',
  },
  {
    id: 'workflows',
    icon: <GitBranch />,
    label: { en: 'Workflows', vi: 'Quy trình' },
    route: '/agents/workflows',
  },
  {
    id: 'providers',
    icon: <Cloud />,
    label: { en: 'LLM Providers', vi: 'Nhà cung cấp LLM' },
    route: '/agents/providers',
  },
  {
    id: 'analytics',
    icon: <TrendingUp />,
    label: { en: 'Analytics', vi: 'Phân tích' },
    route: '/agents/analytics',
  },
  {
    id: 'settings',
    icon: <Settings />,
    label: { en: 'Settings', vi: 'Cài đặt' },
    route: '/agents/settings',
  },
];
```

**Visual States:**
- **Collapsed:** Show icons only (48px wide)
- **Expanded:** Show icons + labels (240px wide)
- **Active Item:** Highlighted with accent color + left border
- **Hover:** Background tint + tooltip (when collapsed)

***

### **1.4 Main Content Area: Agent Configuration**

#### **Tab 1: Agent List View**

**Layout:** Data table with actions

```
┌──────────────────────────────────────────────────────────────┐
│  🤖 Agents                                    [+ New Agent]   │
├──────────────────────────────────────────────────────────────┤
│  🔍 Search agents...          [Filter ▼] [Sort ▼] [View ⊞]  │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Name         │ Type    │ Status │ Provider │ Actions   │ │
│  ├────────────────────────────────────────────────────────┤ │
│  │ 🎭 Orchestrator │ System  │ ● Active │ Gemini   │ [⚙][📊][⏸]│ │
│  │ 💻 Coder        │ Coding  │ ● Active │ Claude   │ [⚙][📊][⏸]│ │
│  │ 🎨 Designer     │ Asset   │ ⏸ Paused │ DALL-E  │ [⚙][📊][▶]│ │
│  │ ✅ Validator    │ Testing │ ● Active │ GPT-4   │ [⚙][📊][⏸]│ │
│  │ 📋 Planner      │ Strategy│ 🔴 Error │ Gemini   │ [⚙][📊][🔄]│ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  Showing 5 of 12 agents                      [1] 2 3 [→]   │
└──────────────────────────────────────────────────────────────┘
```

**Table Features:**
- **Sortable Columns:** Click header to sort
- **Filterable:** By type, status, provider
- **Quick Actions:**
  - ⚙ Configure
  - 📊 View Analytics
  - ⏸ Pause/▶ Resume
  - 🔄 Retry (if error)
- **Bulk Actions:** Select multiple → Pause All, Delete, Export Config

***

#### **Tab 2: Agent Configuration Form**

**When user clicks "Configure" on an agent:**

```
┌──────────────────────────────────────────────────────────────┐
│  [← Back] Configure Agent: Coder                             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────  General  ──────────────┐                  │
│  │ Name: [Coder                       ]  │                  │
│  │ Type: [Coding Agent ▼              ]  │                  │
│  │ Description:                          │                  │
│  │ [Specialized in writing TypeScript... ]│                  │
│  └───────────────────────────────────────┘                  │
│                                                              │
│  ┌──────────────  LLM Provider  ──────────┐                 │
│  │ Provider: ◉ Anthropic Claude                             │
│  │           ○ Google Gemini                                 │
│  │           ○ OpenAI GPT                                    │
│  │                                                           │
│  │ Model:    [claude-3.7-sonnet ▼       ]                   │
│  │ API Key:  [••••••••••••••••••••  ] [👁]                  │
│  │                                                           │
│  │ Advanced Parameters:                                      │
│  │ ┌─────────────────────────────────┐                      │
│  │ │ Temperature:    [0.7  ━━━━○──── 1.0]                  │
│  │ │ Max Tokens:     [4096            ]                    │
│  │ │ Top P:          [0.9  ━━━━━━○── 1.0]                  │
│  │ │ Frequency Pen.: [0.0  ○────────  2.0]                  │
│  │ └─────────────────────────────────┘                      │
│  └──────────────────────────────────────────┘               │
│                                                              │
│  ┌──────────────  Tools Access  ───────────┐                │
│  │ Allowed Tools: (Agent can use these)     │                │
│  │ ☑ read_file      ☑ write_file            │                │
│  │ ☑ list_files     ☑ execute_command       │                │
│  │ ☐ delete_file    ☑ search_code           │                │
│  │ ☐ git_commit     ☐ deploy                 │                │
│  │                                           │                │
│  │ [+ Add Custom Tool]                       │                │
│  └───────────────────────────────────────────┘               │
│                                                              │
│  ┌──────────────  Behavior & Safety  ──────┐                │
│  │ Approval Mode:                            │                │
│  │ ◉ Require approval for destructive actions│                │
│  │ ○ Auto-approve all (risky)                │                │
│  │ ○ Manual approval for every action        │                │
│  │                                           │                │
│  │ Max Actions Per Conversation: [50     ]   │                │
│  │ Timeout (seconds):           [300     ]   │                │
│  │                                           │                │
│  │ ☑ Log all interactions                    │                │
│  │ ☑ Enable safety filters                   │                │
│  │ ☐ Allow file system writes outside /src   │                │
│  └───────────────────────────────────────────┘               │
│                                                              │
│  [Cancel]  [Save Draft]  [Save & Activate]                  │
└──────────────────────────────────────────────────────────────┘
```

**Validation:**
- Required fields: Name, Provider, Model, API Key
- API Key validation: Test connection before save
- Tool permissions: Show warning if destructive tools enabled without approval mode

***

#### **Tab 3: Tool Registry**

**Purpose:** Manage available tools that agents can use

```
┌──────────────────────────────────────────────────────────────┐
│  🔧 Tool Registry                            [+ Register Tool]│
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ Tool Name       │ Category  │ Risk │ Agents Using │ ⚙  ││
│  ├─────────────────────────────────────────────────────────┤│
│  │ 📖 read_file    │ File I/O  │ 🟢 Low │ 5/12        │ [⚙]││
│  │ ✏️ write_file   │ File I/O  │ 🟡 Med │ 3/12        │ [⚙]││
│  │ 🗑️ delete_file  │ File I/O  │ 🔴 High│ 1/12        │ [⚙]││
│  │ ⚙️ execute_cmd   │ Terminal  │ 🔴 High│ 4/12        │ [⚙]││
│  │ 🔍 search_code  │ Search    │ 🟢 Low │ 5/12        │ [⚙]││
│  │ 🐙 git_commit   │ Git       │ 🟡 Med │ 2/12        │ [⚙]││
│  └─────────────────────────────────────────────────────────┘│
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Tool Configuration Modal:**

```
┌────────── Configure Tool: write_file ──────────┐
│                                                 │
│ Display Name: [Write File                   ]  │
│ Description:  [Writes content to a file...  ]  │
│                                                 │
│ Risk Level:   ◉ Low  ◉ Medium  ○ High           │
│                                                 │
│ Approval Required:                              │
│ ☑ Always require user approval                  │
│ ☐ Require approval only if > 500 lines          │
│                                                 │
│ Execution Constraints:                          │
│ ☑ Limit to /src and /public directories         │
│ ☐ Block binary files                            │
│ Max file size: [10 MB]                          │
│                                                 │
│ [Cancel] [Save]                                 │
└─────────────────────────────────────────────────┘
```

***

#### **Tab 4: Workflow Editor (Visual)**

**Purpose:** Define multi-agent workflows (Planner → Coder → Validator)

```
┌──────────────────────────────────────────────────────────────┐
│  🔀 Workflows                              [+ New Workflow]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Select Workflow: [Feature Development ▼]  [▶ Run] [⏸] [📊] │
│                                                              │
│  ┌──────────────── Visual Flow Editor ──────────────────┐   │
│  │                                                       │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ 📋 Planner   │                                  │   │
│  │     │ Analyze req │                                  │   │
│  │     └──────┬──────┘                                  │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ 💻 Coder     │                                  │   │
│  │     │ Write code  │                                  │   │
│  │     └──────┬──────┘                                  │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐      ┌─────────────┐            │   │
│  │     │ ✅ Validator│─────▶│ 🔄 Retry     │            │   │
│  │     │ Run tests   │      │ If failed   │            │   │
│  │     └──────┬──────┘      └─────────────┘            │   │
│  │            │                                          │   │
│  │            ▼                                          │   │
│  │     ┌─────────────┐                                  │   │
│  │     │ ✓ Complete   │                                  │   │
│  │     └─────────────┘                                  │   │
│  │                                                       │   │
│  │  [+ Add Agent Node]  [+ Add Condition]  [🗑️ Delete]  │   │
│  └───────────────────────────────────────────────────────┘   │
│                                                              │
│  Workflow Settings:                                          │
│  • Max iterations: [5  ]                                     │
│  • Timeout: [30 minutes]                                     │
│  • On error: [○ Stop  ◉ Continue  ○ Retry]                   │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Interaction:**
- **Drag-and-drop** agents from sidebar
- **Connect nodes** by dragging from output to input
- **Click node** to configure agent-specific settings
- **Save workflow** as reusable template

***

#### **Tab 5: LLM Provider Management**

```
┌──────────────────────────────────────────────────────────────┐
│  🎛️ LLM Providers                          [+ Add Provider]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─── Anthropic Claude ──────────────────────────┐          │
│  │ Status: ● Connected                           │          │
│  │ API Key: [••••••••••2Kx9] [🔄 Rotate] [Test]  │          │
│  │                                               │          │
│  │ Available Models:                             │          │
│  │ • claude-3.7-sonnet (Default)                 │          │
│  │ • claude-3-opus                               │          │
│  │ • claude-3-haiku                              │          │
│  │                                               │          │
│  │ Usage This Month:                             │          │
│  │ ━━━━━━━━━━━━━━━━━━░░ 85% of quota            │          │
│  │ 42.5M / 50M tokens                            │          │
│  │                                               │          │
│  │ [Configure] [Remove]                          │          │
│  └───────────────────────────────────────────────┘          │
│                                                              │
│  ┌─── Google Gemini ───────────────────────────┐            │
│  │ Status: ⚠ API Key Expired                     │            │
│  │ API Key: [Enter new key...        ] [Save]   │            │
│  └───────────────────────────────────────────────┘          │
│                                                              │
│  ┌─── OpenAI GPT ──────────────────────────────┐            │
│  │ Status: ○ Not Configured                      │            │
│  │ [+ Add OpenAI API Key]                        │            │
│  └───────────────────────────────────────────────┘          │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

***

#### **Tab 6: Analytics Dashboard**

```
┌──────────────────────────────────────────────────────────────┐
│  📈 Agent Analytics                    [Last 7 Days ▼]       │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────── Overview Metrics ─────────────┐              │
│  │  Total Requests      Avg Response Time    │              │
│  │  1,247  ↑12%         2.3s  ↓8%            │              │
│  │                                            │              │
│  │  Success Rate        Token Usage           │              │
│  │  94.2%  ↑2%          4.2M  ↑15%           │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Requests Over Time ───────────┐              │
│  │  300│                          ╱╲          │              │
│  │  200│              ╱╲      ╱╲ ╱  ╲         │              │
│  │  100│         ╱╲  ╱  ╲  ╱ │╱    ╲        │              │
│  │    0└─────────────────────────────────     │              │
│  │     Mon  Tue  Wed  Thu  Fri  Sat  Sun     │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Top Performing Agents ────────┐              │
│  │ 1. Coder      - 543 requests (94% success) │              │
│  │ 2. Validator  - 312 requests (98% success) │              │
│  │ 3. Planner    - 187 requests (92% success) │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
│  ┌──────────── Most Used Tools ───────────────┐              │
│  │ write_file    ████████████░░  82%          │              │
│  │ read_file     ███████████░░░  75%          │              │
│  │ execute_cmd   ████░░░░░░░░░  35%          │              │
│  │ search_code   ███░░░░░░░░░░  28%          │              │
│  └────────────────────────────────────────────┘              │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

***

### **1.5 Agent Configuration Components**

#### **1.5.1 Agent Card (Reusable Component)**

```typescript
<AgentCard
  agent={{
    name: 'Coder',
    type: 'coding',
    status: 'active',
    provider: 'Claude',
    model: 'claude-3.7-sonnet',
    avatar: '/avatars/coder.svg',
  }}
  onConfigure={() => {}}
  onPause={() => {}}
  onViewAnalytics={() => {}}
/>
```

**Visual:**
```
┌────────────────────────────┐
│  🤖  Coder                 │
│  ━━━━━━━━━━━━━━━━━━━━━    │
│  Type: Coding Agent        │
│  Status: ● Active          │
│  Provider: Anthropic Claude│
│  Model: claude-3.7-sonnet  │
│                            │
│  Last used: 2 mins ago     │
│  Success rate: 94%         │
│                            │
│  [⚙ Configure] [📊 Stats]  │
└────────────────────────────┘
```

***

## **2. Enhanced Project Management UI**

### **2.1 Dashboard Improvements**

**Current Issue:** Generic project cards with minimal info

**Enhanced Version:**

```
┌──────────────────────────────────────────────────────────────┐
│  📁 Projects                    [+ New Project] [Import]     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────┐  ┌─────────────────────┐          │
│  │ 📦 via-gent         │  │ 🚀 ecommerce-app    │          │
│  │ ━━━━━━━━━━━━━━━━━━ │  │ ━━━━━━━━━━━━━━━━━━ │          │
│  │ Last edited: 5m ago │  │ Last edited: 2h ago │          │
│  │ Status: ● Running   │  │ Status: ○ Stopped   │          │
│  │                     │  │                     │          │
│  │ 📊 Activity:        │  │ 📊 Activity:        │          │
│  │ • 12 files changed  │  │ • 3 files changed   │          │
│  │ • 2 commits         │  │ • 0 commits         │          │
│  │ • 5 AI requests     │  │ • 1 AI request      │          │
│  │                     │  │                     │          │
│  │ 🤖 Active Agents:   │  │ 🤖 Active Agents:   │          │
│  │ Coder, Validator    │  │ None                │          │
│  │                     │  │                     │          │
│  │ [Open] [Settings]   │  │ [Open] [Archive]    │          │
│  └─────────────────────┘  └─────────────────────┘          │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Key Additions:**
- **Real-time status** (dev server running?)
- **Activity summary** (files changed, commits, AI usage)
- **Active agents** indicator
- **Quick actions** (Open, Settings, Archive)

***

### **2.2 Project Settings Deep Dive**

**When clicking "Settings" on a project:**

```
┌──────────── Project: via-gent Settings ──────────┐
│                                                   │
│  [General] [Build] [Agents] [Git] [Deploy]       │
│                                                   │
│  ┌──────────── General ─────────────┐            │
│  │ Project Name: [via-gent      ]   │            │
│  │ Description:  [AI-powered IDE... ]│            │
│  │ Root Path:    [/Users/...via-gent]│            │
│  │                                   │            │
│  │ Framework: [TanStack Start ▼  ]  │            │
│  │ Package Manager: [pnpm ▼      ]  │            │
│  └───────────────────────────────────┘            │
│                                                   │
│  ┌──────────── Agents ──────────────┐            │
│  │ Enabled Agents: (Project-specific)│            │
│  │ ☑ Coder      ☑ Validator          │            │
│  │ ☑ Planner    ☐ Designer           │            │
│  │                                   │            │
│  │ Agent Presets:                    │            │
│  │ ○ Minimal (Coder only)            │            │
│  │ ◉ Standard (Coder + Validator)     │            │
│  │ ○ Full Team (All agents)          │            │
│  └───────────────────────────────────┘            │
│                                                   │
│  [Cancel] [Save]                                  │
└───────────────────────────────────────────────────┘
```

***

## **3. Unified IDE Workspace with Collapsible Sidebar**

### **3.1 IDE Layout Enhancements**

**Current Issue:** Fixed layout, no transitions between workspaces

**Enhanced Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│  [☰] via-gent/c6bb2119... [Auto-sync: On] [Sync Now] [⚙]   │
├─────────────────────────────────────────────────────────────┤
│ │                   │                 │                     │
│ │  Sidebar (48px)   │  Editor Area    │  Preview/Chat      │
│ │  [Collapsible]    │                 │  (Resizable)       │
│ │                   │                 │                     │
│ │  [📁] Files       │  Monaco Editor  │  Live Preview      │
│ │  [🔍] Search      │                 │                     │
│ │  [🤖] Agents      │                 │                     │
│ │  [🐙] Git         │                 │                     │
│ │  [⚙] Settings     │                 │                     │
│ │  ────────────     │                 │  OR                │
│ │  [💬] Chat        │                 │                     │
│ │  [📊] Analytics   │                 │  Agent Chat        │
│ │  [🎨] Assets      │                 │                     │
│ │                   │                 │                     │
│ └───────────────────┴─────────────────┴─────────────────────┘
│ │  Terminal (Bottom, Collapsible)                          │
└─────────────────────────────────────────────────────────────┘
```

***

### **3.2 Icon Sidebar (Left) - Collapsible**

**Inspiration:** VS Code Activity Bar

**States:**
1. **Collapsed (48px):** Show icons only
2. **Expanded (280px):** Show icons + content panel

**Icons with Tooltips:**

```typescript
const sidebarIcons = [
  { icon: <Files />, label: 'Explorer', tooltip: 'Cmd+Shift+E', panel: 'file-tree' },
  { icon: <Search />, label: 'Search', tooltip: 'Cmd+Shift+F', panel: 'search' },
  { icon: <Bot />, label: 'Agents', tooltip: 'Cmd+Shift+A', panel: 'agents', badge: 3 },
  { icon: <GitBranch />, label: 'Source Control', tooltip: 'Cmd+Shift+G', panel: 'git' },
  { icon: <Settings2 />, label: 'Settings', tooltip: 'Cmd+,', panel: 'settings' },
  // --- Divider ---
  { icon: <MessageSquare />, label: 'Chat', tooltip: 'Cmd+L', panel: 'chat' },
  { icon: <BarChart3 />, label: 'Analytics', tooltip: null, panel: 'analytics' },
  { icon: <Palette />, label: 'Assets', tooltip: 'Cmd+Shift+P', panel: 'assets' },
];
```

**Interaction:**
- **Click icon:** Toggle panel (if same icon, close; if different, switch)
- **Hover:** Show tooltip with keyboard shortcut
- **Badge:** Show notification count (e.g., 3 pending agent approvals)

***

### **3.3 Dynamic Content Panels**

#### **Panel: File Explorer (📁)**

```
┌──────────── EXPLORER ────────────┐
│  via-gent                         │
│  ▼ src                            │
│    ▼ components                   │
│      ▶ ide                        │
│      ▶ layout                     │
│      │ Button.tsx          M     │
│      │ Input.tsx                 │
│    ▼ routes                       │
│      │ _index.tsx          M     │
│      ▶ workspace                  │
│    ▶ lib                          │
│  ▶ public                         │
│  ▶ node_modules                   │
│    package.json                   │
│    tsconfig.json                  │
│                                   │
│  [+ New File] [+ New Folder]      │
└───────────────────────────────────┘
```

**Features:**
- **Git status indicators:** M (modified), A (added), D (deleted)
- **Context menu:** Right-click for rename, delete, reveal in finder
- **Drag-and-drop:** Move files between folders

***

#### **Panel: Agent Management (🤖)**

```
┌──────────── AGENTS ──────────────┐
│  Active Agents (3)                │
│                                   │
│  🤖 Coder                         │
│  Status: ● Working                │
│  Task: "Add login form"           │
│  Progress: ━━━━━━░░ 75%           │
│  [Pause] [View Details]           │
│                                   │
│  ✅ Validator                     │
│  Status: ⏸ Idle                   │
│  Last run: 5m ago                 │
│  [Resume] [View Logs]             │
│                                   │
│  📋 Planner                       │
│  Status: ○ Disabled               │
│  [Enable]                         │
│                                   │
│  ─────────────────────────        │
│  [+ Assign New Agent]             │
│  [⚙ Configure All]                │
└───────────────────────────────────┘
```

**Features:**
- **Real-time status** updates via WebSocket
- **Quick actions** (Pause, Resume, View)
- **Assign new agent** to current project

***

## **4. Robust Agent Chat Interface**

### **4.1 Enhanced Chat UI**

**Current Issue:** Basic chat without context, no tool visibility

**Enhanced Chat:**

```
┌──────────────────────────────────────────────────────────────┐
│  💬 Agent Chat                        [Clear] [Export] [⚙]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────── Conversation Thread ──────────────┐       │
│  │                                                   │       │
│  │  👤 You (2:30 PM)                                 │       │
│  │  Add a login form with email and password        │       │
│  │                                                   │       │
│  │  🤖 Coder (2:30 PM)                               │       │
│  │  I'll create a login form component. Here's my   │       │
│  │  plan:                                            │       │
│  │  1. Create LoginForm.tsx in src/components        │       │
│  │  2. Add form validation with Zod                  │       │
│  │  3. Wire up to authentication service             │       │
│  │                                                   │       │
│  │  [Approve Plan] [Modify] [Cancel]                 │       │
│  │                                                   │       │
│  │  ──────────────────────────────────────           │       │
│  │                                                   │       │
│  │  🤖 Coder (2:31 PM)                               │       │
│  │  Executing plan...                                │       │
│  │                                                   │       │
│  │  ┌──────── Tool Execution Log ────────┐         │       │
│  │  │ ✓ write_file: src/components/...   │ (0.2s)  │       │
│  │  │ ✓ write_file: src/lib/auth.ts      │ (0.1s)  │       │
│  │  │ ⏳ execute_command: pnpm add zod   │ (running)│       │
│  │  └────────────────────────────────────┘         │       │
│  │                                                   │       │
│  │  Done! The login form is ready. Check the        │       │
│  │  preview panel.                                   │       │
│  │                                                   │       │
│  │  [📎 Files Changed (3)]  [📊 View Diff]           │       │
│  │                                                   │       │
│  └───────────────────────────────────────────────────┘       │
│                                                              │
│  ┌──────────── Context (Optional) ──────────────┐           │
│  │ Selected Files: (Attach to conversation)     │           │
│  │ • src/routes/_index.tsx                      │           │
│  │ • src/lib/auth.ts                            │           │
│  │ [+ Add Files]                                │           │
│  └──────────────────────────────────────────────┘           │
│                                                              │
│  ┌──────────── Input ───────────────────────────┐           │
│  │ [Type your message...                      ] │           │
│  │ [📎 Attach] [🎤 Voice] [Send ➤]              │           │
│  └──────────────────────────────────────────────┘           │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

***

### **4.2 Chat Features Breakdown**

#### **4.2.1 Message Types**

```typescript
type Message = 
  | UserMessage
  | AgentTextMessage
  | AgentPlanMessage
  | AgentToolExecutionMessage
  | SystemMessage;

interface AgentPlanMessage {
  type: 'agent_plan';
  content: string; // Markdown formatted
  steps: Array<{
    description: string;
    tools: string[];
  }>;
  requiresApproval: boolean;
}

interface AgentToolExecutionMessage {
  type: 'tool_execution';
  tools: Array<{
    name: string;
    status: 'running' | 'success' | 'error';
    duration: number;
    result?: any;
  }>;
}
```

***

#### **4.2.2 Agent Plan Approval UI**

**When agent proposes a plan:**

```
┌────────────────────────────────────────┐
│  🤖 Agent Proposal                     │
├────────────────────────────────────────┤
│  I'll implement the login form with:   │
│                                         │
│  ✓ Email/password validation            │
│  ✓ Form submission handling             │
│  ✓ Error messaging UI                   │
│                                         │
│  Files to be created/modified:          │
│  • ➕ src/components/LoginForm.tsx      │
│  • ✏️ src/routes/login.tsx              │
│  • ✏️ src/lib/auth.ts                   │
│                                         │
│  Tools I'll use:                        │
│  • write_file (3 times)                 │
│  • execute_command (install zod)        │
│                                         │
│  ⚠ This will modify 2 existing files    │
│                                         │
│  [✓ Approve] [✎ Modify Request] [✕ Cancel]
└────────────────────────────────────────┘
```

***

#### **4.2.3 Tool Execution Visualization**

**Real-time tool execution display:**

```
┌──────── Tool Execution ────────┐
│  ⏳ write_file                  │
│     Creating LoginForm.tsx...  │
│     Progress: ━━━━━━░░ 75%     │
│                                │
│  ✓ execute_command (0.8s)      │
│     pnpm add zod               │
│     ✓ Installed zod@4.2.1      │
│                                │
│  ✓ write_file (0.1s)           │
│     Modified src/lib/auth.ts   │
│     + 15 lines                 │
└────────────────────────────────┘
```

***

#### **4.2.4 Conversation Threading**

**Support for sub-conversations:**

```
👤 You: Add a login form

🤖 Coder: Done! [Expand for details ▼]

  👤 You: Actually, can you add a "Forgot Password" link?
  
  🤖 Coder: Sure, I'll add that...
  
  [2 messages in thread]

👤 You: Now add a signup page
```

***

### **4.3 Chat Settings Panel**

**Click ⚙ icon in chat header:**

```
┌──────── Chat Settings ────────┐
│                               │
│  Model Selection:              │
│  • Coder: claude-3.7-sonnet   │
│  • Planner: gemini-2.0-pro    │
│                               │
│  Behavior:                     │
│  ☑ Auto-apply safe changes     │
│  ☐ Always require approval     │
│  ☑ Show tool execution logs    │
│                               │
│  Max messages: [100        ]  │
│  Context window: [16K      ]  │
│                               │
│  [Save]                        │
└───────────────────────────────┘
```

***

## **5. Component Library & Design System**

### **5.1 Color System (i18n-aware)**

```typescript
// Semantic tokens (EN/VI labels in tooltips)
const colors = {
  background: {
    DEFAULT: 'hsl(222.2, 84%, 4.9%)',
    muted: 'hsl(217.2, 32.6%, 17.5%)',
    tooltip: { en: 'Main background', vi: 'Nền chính' }
  },
  primary: {
    DEFAULT: 'hsl(217.2, 91.2%, 59.8%)',
    foreground: 'hsl(222.2, 47.4%, 11.2%)',
    tooltip: { en: 'Primary actions', vi: 'Hành động chính' }
  },
  agent: {
    active: 'hsl(142, 76%, 36%)',    // Green
    paused: 'hsl(38, 92%, 50%)',      // Yellow
    error: 'hsl(0, 84%, 60%)',        // Red
    idle: 'hsl(215, 20%, 65%)',       // Gray
  },
};
```

***

### **5.2 Typography (Multilingual)**

```css
/* Primary font stack (supports Vietnamese diacritics) */
body {
  font-family: 'Inter', -apple-system, 'Segoe UI', sans-serif;
  font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
}

/* Code font */
code, pre {
  font-family: 'JetBrains Mono', 'Fira Code', monospace;
}

/* Vietnamese-specific adjustments */
html[lang="vi"] {
  letter-spacing: -0.01em; /* Tighter for diacritics */
}
```

***

### **5.3 Key UI Components**

#### **5.3.1 Agent Status Badge**

```typescript
<AgentStatusBadge 
  status="active" // active | paused | error | idle
  size="sm" // sm | md | lg
  showLabel={true}
/>

// Renders:
// ● Active (EN) | ● Đang hoạt động (VI)
```

***

#### **5.3.2 Tool Execution Badge**

```typescript
<ToolBadge
  name="write_file"
  status="success" // running | success | error
  duration={245} // ms
/>

// Renders:
// ✓ write_file (0.2s)
```

***

#### **5.3.3 Approval Dialog**

```typescript
<ApprovalDialog
  title={{ en: 'Agent Proposal', vi: 'Đề xuất của Agent' }}
  description="Coder wants to modify 3 files"
  changes={[
    { type: 'create', file: 'LoginForm.tsx' },
    { type: 'modify', file: 'auth.ts', lines: '+15/-3' },
  ]}
  onApprove={() => {}}
  onReject={() => {}}
  onModify={() => {}}
/>
```

***

## **6. Responsive Layouts & Navigation**

### **6.1 Navigation Flow**

```
Landing Page → Dashboard → Workspace Selection
                ↓
        ┌───────┴────────┐
        │                │
    IDE Mode      Agent Management
        │                │
        └────────┬───────┘
                 ↓
          Settings Panel
```

***

### **6.2 Global Navigation Bar**

```
┌──────────────────────────────────────────────────────────┐
│ [☰] Via-Gent  Projects  IDE  Agents  Settings  [🔔][👤] │
└──────────────────────────────────────────────────────────┘
```

**Behavior:**
- **Always visible** across all screens
- **Active route** highlighted
- **Notifications bell** shows pending agent approvals
- **User menu** (top-right) → Account, Logout

***

## **7. i18n Implementation**

### **7.1 Translation Structure**

```json
// locales/en/common.json
{
  "nav": {
    "projects": "Projects",
    "ide": "IDE",
    "agents": "Agents",
    "settings": "Settings"
  },
  "agents": {
    "status": {
      "active": "Active",
      "paused": "Paused",
      "error": "Error",
      "idle": "Idle"
    },
    "actions": {
      "configure": "Configure",
      "pause": "Pause",
      "resume": "Resume",
      "delete": "Delete"
    }
  }
}

// locales/vi/common.json
{
  "nav": {
    "projects": "Dự án",
    "ide": "IDE",
    "agents": "Đại lý AI",
    "settings": "Cài đặt"
  },
  "agents": {
    "status": {
      "active": "Đang hoạt động",
      "paused": "Tạm dừng",
      "error": "Lỗi",
      "idle": "Rảnh rỗi"
    }
  }
}
```

***

### **7.2 Usage in Components**

```typescript
import { useTranslation } from 'react-i18next';

function AgentCard({ agent }: AgentCardProps) {
  const { t } = useTranslation('common');
  
  return (
    <Card>
      <CardHeader>
        <h3>{agent.name}</h3>
        <Badge>{t(`agents.status.${agent.status}`)}</Badge>
      </CardHeader>
      <CardFooter>
        <Button>{t('agents.actions.configure')}</Button>
        <Button>{t('agents.actions.pause')}</Button>
      </CardFooter>
    </Card>
  );
}
```

***

## 📋 **Implementation Roadmap**

### **Epic 15: Agent Management Dashboard (3 weeks)**

**Week 1: Core Infrastructure**
- Agent list table with sorting/filtering
- Agent configuration form
- Tool registry management

**Week 2: Advanced Features**
- Workflow visual editor
- LLM provider management
- Analytics dashboard

**Week 3: Polish & Integration**
- i18n for all components
- Responsive layouts
- Integration with existing IDE

***

### **Epic 16: Enhanced Chat Interface (2 weeks)**

**Week 1: Chat UX**
- Threaded conversations
- Tool execution visualization
- Approval flow UI

**Week 2: Context & Settings**
- File attachment to conversations
- Chat settings panel
- Export/import conversations

***